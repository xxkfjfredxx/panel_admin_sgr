export const API_ROUTES = {
  LOGIN: '/login/',
  LOGOUT: '/logout/',

  EMPRESAS: '/companies/',
  EMPRESAS_MY: '/companies/my-companies/',

  USUARIOS: '/users/',
  EMPLEADOS: '/empleados/',
  CONTRATOS: '/contratos/',
  // agrega más según lo que ya descubrimos en el backend
};