export const API_ROUTES = {
  LOGIN: '/auth//login',
  LOGOUT: '/auth//logout',

  EMPRESAS: '/v1/companies/',
  EMPRESAS_MY: '/v1/companies/my-companies/',

  USUARIOS: '/v1/v1/users/',
  EMPLEADOS: '/v1/empleados/',
  CONTRATOS: '/v1/contratos/',
  // agrega más según lo que ya descubrimos en el backend
};